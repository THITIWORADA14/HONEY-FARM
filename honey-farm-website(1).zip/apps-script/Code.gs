// HONEY FARM - Google Apps Script
// 1) สร้าง Google Sheet ใหม่ แล้วคัดลอก Spreadsheet ID จาก URL
// 2) วาง ID ใน SPREADSHEET_ID ด้านล่าง
// 3) Extensions > Apps Script วางโค้ดนี้ แล้ว Deploy > New deployment > Web app
// 4) Execute as: Me | Who has access: Anyone
// 5) นำ Web app URL ไปใส่ใน API_URL ใน app.js

const SPREADSHEET_ID = "ใส่_SPREADSHEET_ID_ที่นี่";
const ORDERS_SHEET = "Orders";
const ITEMS_SHEET = "OrderItems";

function getSheet_(name, headers) {
  const ss = SpreadsheetApp.openById(SPREADSHEET_ID);
  let sh = ss.getSheetByName(name);
  if (!sh) sh = ss.insertSheet(name);
  if (sh.getLastRow() === 0) sh.appendRow(headers);
  return sh;
}
function doGet(e) {
  const action = e && e.parameter && e.parameter.action;
  if (action === "getOrders") {
    const sh = getSheet_(ORDERS_SHEET, ["OrderID","Date","Name","Phone","Address","Note","Total","Status","ItemsJSON"]);
    const values = sh.getDataRange().getValues();
    const orders = values.slice(1).filter(r => r[0]).map(r => ({
      id:String(r[0]), date:r[1], name:r[2], phone:r[3], address:r[4],
      note:r[5], total:Number(r[6]), status:r[7], items:JSON.parse(r[8] || "[]")
    })).reverse();
    return json_({orders});
  }
  return json_({ok:true,service:"HONEY FARM Sheets API"});
}
function doPost(e) {
  const body = JSON.parse(e.postData.contents || "{}");
  const orders = getSheet_(ORDERS_SHEET, ["OrderID","Date","Name","Phone","Address","Note","Total","Status","ItemsJSON"]);
  if (body.action === "newOrder") {
    const o = body.order;
    orders.appendRow([o.id,o.date,o.name,o.phone,o.address,o.note,o.total,o.status,JSON.stringify(o.items)]);
    return json_({ok:true,id:o.id});
  }
  if (body.action === "updateStatus") {
    const rows = orders.getDataRange().getValues();
    for (let i=1;i<rows.length;i++) {
      if (String(rows[i][0]) === String(body.id)) {
        orders.getRange(i+1,8).setValue(body.status);
        return json_({ok:true});
      }
    }
    return json_({ok:false,error:"Order not found"});
  }
  return json_({ok:false,error:"Unknown action"});
}
function json_(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);
}