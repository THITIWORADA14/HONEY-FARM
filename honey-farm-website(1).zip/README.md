# HONEY FARM — เว็บไซต์ขายน้ำผึ้ง

เว็บไซต์ตัวอย่างสำหรับงานเรียน ประกอบด้วยหน้าร้าน, ตะกร้า, Checkout, ระบบหลังบ้าน, Picking List, Packing และใบจ่าหน้าพัสดุสำหรับพิมพ์

## ไฟล์ในโปรเจกต์
- `index.html` — โครงสร้างเว็บไซต์
- `style.css` — ดีไซน์ Responsive
- `app.js` — สินค้า, ตะกร้า, คำสั่งซื้อ และหลังบ้าน
- `apps-script/Code.gs` — API เชื่อม Google Sheets
- `assets/` — โฟลเดอร์สำหรับเก็บรูปภาพสินค้า (เพิ่มไฟล์รูปของร้านได้)

## ทดลองใช้งาน
เปิด `index.html` ในเบราว์เซอร์ได้ทันที ระบบจะเก็บออเดอร์ไว้ใน Local Storage ของอุปกรณ์/เบราว์เซอร์นั้น เหมาะสำหรับทดลองเดโมเท่านั้น

## เชื่อม Google Sheets
1. สร้าง Google Sheet ใหม่ ตั้งชื่อ `HONEY FARM Orders`
2. ไปที่ Extensions > Apps Script
3. เปิดไฟล์ `apps-script/Code.gs` ในโปรเจกต์นี้ แล้วคัดลอกไปวางใน Apps Script
4. ใส่ Spreadsheet ID ในตัวแปร `SPREADSHEET_ID` (ดูจาก URL ของ Google Sheet ระหว่าง `/d/` และ `/edit`)
5. กด Deploy > New deployment > เลือก Web app
6. Execute as: Me และ Who has access: Anyone (เหมาะกับงานเดโมที่ไม่มีข้อมูลส่วนบุคคลจริง)
7. กด Deploy และอนุญาตสิทธิ์ จากนั้นคัดลอก Web app URL
8. เปิด `app.js` แล้วใส่ URL ใน `const API_URL = "..."` จากนั้น commit ไฟล์ขึ้น GitHub อีกครั้ง

Apps Script จะสร้างชีต `Orders` และ `OrderItems` ตามการใช้งาน (ข้อมูลรายการสินค้าเก็บเป็น JSON ใน Orders)

## Deploy ด้วย GitHub + Vercel
1. สร้าง Repository ใหม่บน GitHub ชื่อ `honey-farm`
2. อัปโหลดไฟล์ทั้งหมดในโฟลเดอร์นี้ขึ้น Repository (ให้ `index.html` อยู่ที่ root)
3. เข้า Vercel แล้วเลือก Add New > Project
4. Import Git Repository `honey-farm`
5. Framework Preset: Other; Build Command: เว้นว่าง; Output Directory: `.`; Install Command: เว้นว่าง
6. กด Deploy แล้วใช้ URL ที่ Vercel ให้มา

## ข้อควรรู้
- ราคาสินค้าและรายละเอียดเป็นข้อมูลตัวอย่าง แก้ไขได้ใน `PRODUCTS` ที่ `app.js`
- ก่อนส่งงานจริง ควรทดสอบสั่งซื้อและตรวจข้อมูลใน Google Sheets
- ระบบนี้เป็นต้นแบบเพื่อการเรียน ไม่ใช่ระบบชำระเงินออนไลน์จริง และยังไม่มีระบบล็อกอินผู้ดูแล
- อย่าใช้ข้อมูลลูกค้าจริงในการทดสอบ เพราะ Google Apps Script Web App แบบ Anyone ไม่มีระบบยืนยันตัวตนฝั่งผู้ดูแล
- รูปภาพสินค้าในงานนี้วาดด้วย CSS; สามารถเพิ่มภาพถ่ายจริงใน `assets/` และปรับ HTML ได้
